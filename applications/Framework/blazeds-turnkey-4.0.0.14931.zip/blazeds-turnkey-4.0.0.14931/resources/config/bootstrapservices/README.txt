Bootstrap services can be used to dynamically create services, destinations,
and adapters as server starts up without needing any configuration files.
These bootstrap services can be registered with the MessageBroker in
services-config.xml and they are invoked by the MessageBroker in the order
they are specified. 


� 2004-2010 Adobe Systems Incorporated. All rights reserved. 