BlazeDS Configuration readme file

This directory contains example files for use in J2EE web applications which use
BlazeDS. To use one or more of these files as a starting point
for an application, simply copy the file into the WEB-INF/flex directory and
then edit it according to the comments included.

� 2004-2010 Adobe Systems Incorporated. All rights reserved. 

