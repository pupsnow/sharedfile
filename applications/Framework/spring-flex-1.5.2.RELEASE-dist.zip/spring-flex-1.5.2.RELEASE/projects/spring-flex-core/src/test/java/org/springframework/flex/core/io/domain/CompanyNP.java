package org.springframework.flex.core.io.domain;



public class CompanyNP {

    public Integer id;

    public Integer version;

    public String name;

}
